//
//  ResturantMenuListViewController.swift
//  Project
//
//  Created by CSS on 22/10/18.
//  Copyright © 2018 css. All rights reserved.
//

import UIKit
import ParallaxHeader

struct VEGORNONVEG {
    
    let veg =  "veg"
    let nonVeg = "nonveg"
}

class ResturantMenuListViewController: UIViewController {

    @IBOutlet weak var dividerLine: UIView!
    @IBOutlet weak var tableView: UITableView!
    weak var headerImageView: UIView?
    @IBOutlet weak var tableHeaderView: UIView!
    @IBOutlet weak var addFavorties: UIButton!
    @IBOutlet weak var searchIcon: UIButton!
    @IBOutlet weak var resturantNameLbl: UILabel!
    var lastContentOffset: CGFloat = 0
    var headerHeight: CGFloat = 55
    var catgories: CategoriesList?
    var featuredProducts = [Featured_products]()
    var categoriesArray = [Categories]()
    var productTitleArray = [String]()
    var numberofSection:Int = 0
    private lazy var  loader = {
        return createActivityIndicator(UIApplication.shared.keyWindow ?? self.view)
    }()
    var shop:Int?
    let headerLbl = UILabel()
    var shopList: Shops!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        categoriesList()
        setupParallaxHeader()
        tableView.register(UINib(nibName: XIB.Names.ResturantRatingCell, bundle: nil), forCellReuseIdentifier: XIB.Names.ResturantRatingCell)
        tableView.register(UINib(nibName: XIB.Names.AddCartCell, bundle: nil), forCellReuseIdentifier: XIB.Names.AddCartCell)
        tableView.register(UINib(nibName: XIB.Names.AddCartWithImgView, bundle: nil), forCellReuseIdentifier: XIB.Names.AddCartWithImgView)
        
        tableView.register(UINib(nibName: XIB.Names.SectionHeaderCell, bundle: nil), forCellReuseIdentifier: XIB.Names.SectionHeaderCell)
        
        tableView.separatorStyle = .none
    
    }
    
   
    //MARK: private
    
    private func setupParallaxHeader() {
        
        
       // print("******", shopList.default_bannerzz)
        let imageView = UIImageView()
        imageView.setImage(with: shopList?.default_banner, placeHolder: #imageLiteral(resourceName: "restaurant_placeholder"))
        imageView.contentMode = .scaleAspectFill
        
        headerImageView = imageView
        
        tableView.parallaxHeader.view = imageView
        tableView.parallaxHeader.height = 250
        tableView.parallaxHeader.minimumHeight = 0
        tableView.parallaxHeader.mode = .centerFill
        tableView.parallaxHeader.parallaxHeaderDidScrollHandler = { parallaxHeader in
            //update alpha of blur view on top of image view
            parallaxHeader.view.blurView.alpha = 1 - parallaxHeader.progress
        }
        
        // Label for vibrant text
        let titleLbl = UILabel()
        titleLbl.frame = CGRect(x: 15, y: 180, width: tableView.frame.width - (2 * 15), height: 20)
        titleLbl.text = "Herbal"
        Common.setFont(to: titleLbl, isTitle: true, size: 16, fontType: .semiBold)
        titleLbl.textAlignment = .left
        titleLbl.textColor = .white
        imageView.addSubview(titleLbl)
        
        // Label for vibrant text
        let descriptionLbl = UILabel()
        descriptionLbl.frame = CGRect(x: 15, y: titleLbl.frame.maxY + 2, width: tableView.frame.width - (2 * 15), height: 20)
        descriptionLbl.text = "Hot and spicy !!!"
        Common.setFont(to: descriptionLbl, isTitle: true, size: 14, fontType: .semiBold)
        descriptionLbl.textAlignment = .left
        descriptionLbl.textColor = .white
        imageView.addSubview(descriptionLbl)
        
        self.dividerLine.isHidden = true
        self.tableHeaderView.backgroundColor = .clear
    }
    
    
    //MARK: actions
    
    @objc private func imageDidTap(gesture: UITapGestureRecognizer) {
        UIView.animate(withDuration: 0.3) {
            if self.tableView.parallaxHeader.height == 400 {
                self.tableView.parallaxHeader.height = 200
               
            } else {
                self.tableView.parallaxHeader.height = 400
               
            }
        }
    }
    
    
 
}


extension ResturantMenuListViewController {
    
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        
        if (self.lastContentOffset < scrollView.contentOffset.y) {
            self.dividerLine.isHidden = false
            self.tableHeaderView.backgroundColor = .white
            self.resturantNameLbl.isHidden = false
        } else if (self.lastContentOffset > scrollView.contentOffset.y) {
            self.dividerLine.isHidden = true
            self.tableHeaderView.backgroundColor = .clear
            self.resturantNameLbl.isHidden = true
           
        } else {
            // didn't move
        }
    }
    
    //MARK:- Show Custom Toast
    private func showToast(string : String?) {
        
        self.view.makeToast(string, point: CGPoint(x: UIScreen.main.bounds.width/2 , y: UIScreen.main.bounds.height/2), title: nil, image: nil, completion: nil)
        
    }
}

//MARK: - UITableViewDelegate & UITableViewDatasource

extension ResturantMenuListViewController: UITableViewDataSource, UITableViewDelegate {
    
  
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if section == 0 {
             return 1
        } else if section == 1 {
        
            return featuredProducts.count > 0 ? featuredProducts.count + 1 : 0
        } else {
            return categoriesArray.count > 0 ? (categoriesArray[section-2].products?.count)! + 1 : 0
            
        }
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return numberofSection
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        if indexPath.section == 0 {
             return 84
        } else if indexPath.section == 1 {
            if indexPath.row ==  0 {
                return 50
            } else {
                return 232
            }
        } else {
            if indexPath.row ==  0 {
                return 50
            } else {
                return 65
            }
           
        }
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if indexPath.section == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: XIB.Names.ResturantRatingCell, for: indexPath) as! ResturantRatingCell
            cell.selectionStyle = .none
            cell.backgroundColor = .clear
            return cell
        } else if indexPath.section == 1 {
            
            
            
            if indexPath.row ==  0 {
                
                let cell = tableView.dequeueReusableCell(withIdentifier: XIB.Names.SectionHeaderCell, for: indexPath) as! SectionHeaderCell
                cell.selectionStyle = .none
                cell.backgroundColor = .clear
                
                cell.titleLbl.text = Constants.string.featuredProducts.localize()
                
                return cell
            } else {
                
                let cell = tableView.dequeueReusableCell(withIdentifier: XIB.Names.AddCartWithImgView, for: indexPath) as! AddCartWithImgView
                cell.selectionStyle = .none
                cell.backgroundColor = .clear
                
                
                if featuredProducts.count > 0 && featuredProducts.count > indexPath.row - 1 {
                    
                    let productEntity = featuredProducts[indexPath.row - 1]
                    if (productEntity.images?.count)! > 0 {
                        let imageEntity = productEntity.images?[0]  as! Images
                        cell.productImg.setImage(with: imageEntity.url, placeHolder: #imageLiteral(resourceName: "product_placeholder"))
                    }
                    
                    if productEntity.food_type == VEGORNONVEG().veg {
                        cell.vegOrNonVegIcon.image = #imageLiteral(resourceName: "veg")
                    } else {
                        
                        cell.vegOrNonVegIcon.image = #imageLiteral(resourceName: "nonveg")
                    }
                    
                    cell.dishNameLbl.text = productEntity.name
                    cell.priceLbl.text = "\(productEntity.prices?.price! ?? 0)"
                    cell.addButton.addTarget(self, action: #selector(addCart), for: .touchUpInside)
                    
                    
                    return cell
                }
                
                
            }
            
        } else {
            
            
            if indexPath.row ==  0 {
                
                let cell = tableView.dequeueReusableCell(withIdentifier: XIB.Names.SectionHeaderCell, for: indexPath) as! SectionHeaderCell
                cell.selectionStyle = .none
                cell.backgroundColor = .clear
                
                
                    cell.titleLbl.text = categoriesArray[indexPath.section-2].name
                
                
                
                return cell
            } else {
                
                
                let cell = tableView.dequeueReusableCell(withIdentifier: XIB.Names.AddCartCell, for: indexPath) as! AddCartCell
                cell.selectionStyle = .none
                cell.backgroundColor = .clear
                
                
                if (categoriesArray[indexPath.section-2].products?.count)! > 0  &&  (categoriesArray[indexPath.section-2].products?.count)! > indexPath.row - 1 {
                    
                    let productEntity = categoriesArray[indexPath.section-2].products?[indexPath.row - 1]
                    
                    cell.priceLbl.text =  "\(productEntity?.prices?.price! ?? 0)"
                    cell.tilteLbl.text = productEntity?.name
                    
                    if productEntity?.food_type == VEGORNONVEG().veg {
                        cell.vegIcon.image = #imageLiteral(resourceName: "veg")
                    } else {
                        
                        cell.vegIcon.image = #imageLiteral(resourceName: "nonveg")
                    }
                }
                
                return cell
            }
        }
         return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let menuVC = Router.main.instantiateViewController(withIdentifier: Storyboard.Ids.AddOnsViewController) as! AddOnsViewController
        self.navigationController?.pushViewController(menuVC, animated: true)
    }
    
}
  

extension ResturantMenuListViewController {
  
    @objc func addCart(sender: UIButton) {
        
    }
    
    @IBAction func backToPreviousScreen(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
}


//MARK: - PostViewProtocol

extension ResturantMenuListViewController: PostViewProtocol {
    
    func onError(api: Base, message: String, statusCode code: Int) {
        
        self.loader.isHidden = true
        self.showToast(string: message)
    }
    
    func categoriesList() {
        
        if User.main.id != nil {
            self.catgories = CategoriesList()
            catgories?.shop = self.shop
            catgories?.user_id = User.main.id
            self.loader.isHidden = false
            self.presenter?.get(api: .categoriesList, data: catgories?.toData())
        } else {
            self.catgories = CategoriesList()
            catgories?.shop = self.shop
            self.loader.isHidden = false
            self.presenter?.get(api: .categoriesList, data: catgories?.toData())
        }
    }
    
    
    func menuList(api: Base, data: ResturantMenuList?) {
        
        if api == .categoriesList, data != nil {
            
             self.loader.isHidden = true
            
            if (data?.featured_products)!.count > 0 {
                
                featuredProducts = (data?.featured_products)!
            }

            if (data?.categories?.count)! > 0 {
                
                categoriesArray = (data?.categories)!
                
                var title: String?
                for item in categoriesArray {
                    
                   
                      productTitleArray.append(item.name!)
                    
                    
                }
                
               
            }
            
       
         numberofSection = 4
         tableView.reloadData()
    
        }
    }

}
